**What is Kerbal Edit?**
KerbalEdit is a Reference application based upon the KerbalData  (https://kerbaldata.codeplex.com). It is a fully usable
end user application with source to give other developers a guide in thier own KerbalData Applications.

![](Home_http://i.imgur.com/4oc17iP.png)

KerbalEdit allows you to:

* Load/Edit/Save KSP Save, Craft (both global and under a specific save), Part and game settings.
* Scan a KSP install for all available data files
* Import/Export Files to your game quickly
* Automatically backs up changed files, keeps a copy of original data to restore live object.
* Save Development Time : Time Savings
* Do simple popular actions
	* Clear all debris and unknown items from a save
	* Put any craft currently in game (on the pad or in orbit) in orbit around any body
	* Refuel any or all craft in your save with a single command (fills any resource to max)
	* more to come (looking for suggestions)...

Want to make your own app using KSP data? [KerbalData makes it easy!](http://kerbaldata.codeplex.com/)
